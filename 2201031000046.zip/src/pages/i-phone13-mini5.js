import "./i-phone13-mini5.css";

const IPhone13Mini5 = () => {
  return (
    <div className="iphone-13-mini-6">
      <img className="edit-cart-icon" alt="" src="/edit-cart@2x.png" />
    </div>
  );
};

export default IPhone13Mini5;
