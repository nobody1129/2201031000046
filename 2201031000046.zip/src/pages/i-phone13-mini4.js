import "./i-phone13-mini4.css";

const IPhone13Mini4 = () => {
  return (
    <div className="iphone-13-mini-5">
      <img
        className="food-details-02-icon"
        alt=""
        src="/food-details-02@2x.png"
      />
    </div>
  );
};

export default IPhone13Mini4;
