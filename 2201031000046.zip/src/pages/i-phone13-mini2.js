import "./i-phone13-mini2.css";

const IPhone13Mini2 = () => {
  return (
    <div className="iphone-13-mini-3">
      <img className="home-v-icon" alt="" src="/home-v@2x.png" />
    </div>
  );
};

export default IPhone13Mini2;
