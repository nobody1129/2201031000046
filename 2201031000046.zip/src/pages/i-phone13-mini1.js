import "./i-phone13-mini1.css";

const IPhone13Mini1 = () => {
  return (
    <div className="iphone-13-mini-2">
      <img className="sign-up-icon" alt="" src="/sign-up@2x.png" />
    </div>
  );
};

export default IPhone13Mini1;
