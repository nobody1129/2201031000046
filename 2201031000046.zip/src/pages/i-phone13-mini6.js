import "./i-phone13-mini6.css";

const IPhone13Mini6 = () => {
  return (
    <div className="iphone-13-mini-7">
      <img className="address-icon" alt="" src="/address@2x.png" />
    </div>
  );
};

export default IPhone13Mini6;
