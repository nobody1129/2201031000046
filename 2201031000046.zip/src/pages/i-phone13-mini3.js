import "./i-phone13-mini3.css";

const IPhone13Mini3 = () => {
  return (
    <div className="iphone-13-mini-4">
      <img className="search-icon" alt="" src="/search@2x.png" />
    </div>
  );
};

export default IPhone13Mini3;
