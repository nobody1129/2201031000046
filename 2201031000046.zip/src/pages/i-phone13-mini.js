import "./i-phone13-mini.css";

const IPhone13Mini = () => {
  return (
    <div className="iphone-13-mini-1">
      <img className="log-in-empty-icon" alt="" src="/log-in-empty@2x.png" />
    </div>
  );
};

export default IPhone13Mini;
