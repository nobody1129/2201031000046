import { useEffect } from "react";
import {
  Routes,
  Route,
  useNavigationType,
  useLocation,
} from "react-router-dom";
import IPhone13Mini from "./pages/i-phone13-mini";
import IPhone13Mini1 from "./pages/i-phone13-mini1";
import IPhone13Mini2 from "./pages/i-phone13-mini2";
import IPhone13Mini3 from "./pages/i-phone13-mini3";
import IPhone13Mini4 from "./pages/i-phone13-mini4";
import IPhone13Mini5 from "./pages/i-phone13-mini5";
import IPhone13Mini6 from "./pages/i-phone13-mini6";

function App() {
  const action = useNavigationType();
  const location = useLocation();
  const pathname = location.pathname;

  useEffect(() => {
    if (action !== "POP") {
      window.scrollTo(0, 0);
    }
  }, [action, pathname]);

  useEffect(() => {
    let title = "";
    let metaDescription = "";

    switch (pathname) {
      case "/":
        title = "";
        metaDescription = "";
        break;
      case "/iphone-13-mini-2":
        title = "";
        metaDescription = "";
        break;
      case "/iphone-13-mini-3":
        title = "";
        metaDescription = "";
        break;
      case "/iphone-13-mini-4":
        title = "";
        metaDescription = "";
        break;
      case "/iphone-13-mini-5":
        title = "";
        metaDescription = "";
        break;
      case "/iphone-13-mini-6":
        title = "";
        metaDescription = "";
        break;
      case "/iphone-13-mini-7":
        title = "";
        metaDescription = "";
        break;
    }

    if (title) {
      document.title = title;
    }

    if (metaDescription) {
      const metaDescriptionTag = document.querySelector(
        'head > meta[name="description"]'
      );
      if (metaDescriptionTag) {
        metaDescriptionTag.content = metaDescription;
      }
    }
  }, [pathname]);

  return (
    <Routes>
      <Route path="/" element={<IPhone13Mini />} />
      <Route path="/iphone-13-mini-2" element={<IPhone13Mini1 />} />
      <Route path="/iphone-13-mini-3" element={<IPhone13Mini2 />} />
      <Route path="/iphone-13-mini-4" element={<IPhone13Mini3 />} />
      <Route path="/iphone-13-mini-5" element={<IPhone13Mini4 />} />
      <Route path="/iphone-13-mini-6" element={<IPhone13Mini5 />} />
      <Route path="/iphone-13-mini-7" element={<IPhone13Mini6 />} />
    </Routes>
  );
}
export default App;
